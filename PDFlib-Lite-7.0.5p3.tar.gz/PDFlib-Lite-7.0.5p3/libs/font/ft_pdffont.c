/*---------------------------------------------------------------------------*
 |              PDFlib - A library for generating PDF on the fly             |
 +---------------------------------------------------------------------------+
 |        Copyright (c) 2002-2006 PDFlib GmbH. All rights reserved.          |
 +---------------------------------------------------------------------------+
 |          Proprietary source code -- do not redistribute!                  |
 *---------------------------------------------------------------------------*/

/* $Id: ft_pdffont.c,v 1.140.2.5 2007/02/16 18:35:55 kurt Exp $
 *
 * Routine for parsing font dictionaries in PDF files by pCOS
 *
 */

#include "ft_pdffont.h"
#include "ft_truetype.h"


