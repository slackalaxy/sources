/*---------------------------------------------------------------------------*
 |                   PDC -- PDF content stream parser                        |
 +---------------------------------------------------------------------------+
 |           Copyright (c) 2002 PDFlib GmbH. All rights reserved.            |
 *---------------------------------------------------------------------------*
 |          Proprietary source code -- do not redistribute!                  |
 *---------------------------------------------------------------------------*/

/* $Id: pc_scan.c,v 1.13.2.5 2007/05/21 20:55:12 york Exp $ */


#include "pc_util.h"
#include "pc_strconst.h"
#include "pc_ctype.h"
#include "pc_scan.h"

#include "pc_string.h"


