/*---------------------------------------------------------------------------*
 |              PDFlib - A library for generating PDF on the fly             |
 +---------------------------------------------------------------------------+
 | Copyright (c) 1997-2006 Thomas Merz and PDFlib GmbH. All rights reserved. |
 +---------------------------------------------------------------------------+
 |                                                                           |
 |    This software is subject to the PDFlib license. It is NOT in the       |
 |    public domain. Extended versions and commercial licenses are           |
 |    available, please check http://www.pdflib.com.                         |
 |                                                                           |
 *---------------------------------------------------------------------------*/

/* $Id: pc_xmp.c,v 1.38.2.173 2009/12/22 15:03:47 serge Exp $
 *
 * The core XMP support.
 *
 */

#include "pc_ctype.h"
#include "pc_util.h"
#include "pc_strconst.h"
#include "pc_md5.h"































