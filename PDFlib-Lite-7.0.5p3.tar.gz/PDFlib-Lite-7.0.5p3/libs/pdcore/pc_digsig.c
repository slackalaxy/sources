/*---------------------------------------------------------------------------*
 |              PDFlib - A library for generating PDF on the fly             |
 +---------------------------------------------------------------------------+
 |            Copyright (c) 2006 PDFlib GmbH. All rights reserved.           |
 +---------------------------------------------------------------------------+
 |                                                                           |
 |    This software is subject to the PDFlib license. It is NOT in the       |
 |    public domain. Extended versions and commercial licenses are           |
 |    available, please check http://www.pdflib.com.                         |
 |                                                                           |
 *---------------------------------------------------------------------------*/

/* $Id: pc_digsig.c,v 1.6.2.2 2007/01/22 10:36:40 rjs Exp $
 */


/* ANSI C forbids an empty source file */
void pdc_dummy_digsig_c(void);
void pdc_dummy_digsig_c() {}

