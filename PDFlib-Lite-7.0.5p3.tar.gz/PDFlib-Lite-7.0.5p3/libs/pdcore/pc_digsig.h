/*---------------------------------------------------------------------------*
 |              PDFlib - A library for generating PDF on the fly             |
 +---------------------------------------------------------------------------+
 |            Copyright (c) 2006 PDFlib GmbH. All rights reserved.           |
 +---------------------------------------------------------------------------+
 |                                                                           |
 |    This software is subject to the PDFlib license. It is NOT in the       |
 |    public domain. Extended versions and commercial licenses are           |
 |    available, please check http://www.pdflib.com.                         |
 |                                                                           |
 *---------------------------------------------------------------------------*/

/* $Id: pc_digsig.h,v 1.4.2.1 2007/01/22 10:36:40 rjs Exp $
 *
 * Digital Signature hashing/signing routines
 *
 */
