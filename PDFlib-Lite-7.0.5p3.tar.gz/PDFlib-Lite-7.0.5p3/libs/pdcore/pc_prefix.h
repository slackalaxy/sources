/*---------------------------------------------------------------------------*
 |              PDFlib - A library for generating PDF on the fly             |
 +---------------------------------------------------------------------------+
 |          Copyright (c) 1997-2006 PDFlib GmbH. All rights reserved.        |
 +---------------------------------------------------------------------------+
 |          Proprietary source code -- do not redistribute!                  |
 *---------------------------------------------------------------------------*/

/* $Id: pc_prefix.h,v 1.31.2.11 2010/04/26 09:53:19 kurt Exp $
 *
 * PDCORE: unique renaming of function names shared by different applications
 */

#ifndef PC_PREFIX_H
#define PC_PREFIX_H

#endif  /* PC_PREFIX_H */

