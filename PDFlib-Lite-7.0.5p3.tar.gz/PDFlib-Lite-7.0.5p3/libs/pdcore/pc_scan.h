/*---------------------------------------------------------------------------*
 |              PDFlib - A library for generating PDF on the fly             |
 +---------------------------------------------------------------------------+
 | Copyright (c) 1997-2006 Thomas Merz and PDFlib GmbH. All rights reserved. |
 +---------------------------------------------------------------------------+
 |          Proprietary source code -- do not redistribute!                  |
 *---------------------------------------------------------------------------*/

/* $Id: pc_scan.h,v 1.5.2.1 2006/10/23 17:52:20 kurt Exp $ */

#ifndef PC_SCAN_H_INCLUDED
#define PC_SCAN_H_INCLUDED


#endif	/* PC_SCAN_H_INCLUDED */
