--------------------------------------------------------------------------
    -***- Vortigo -***- 

  by Otto Donder (o.donder@chairod.de)

  My second XMMS/Audacious/Winamp_5 - Skin.

  2007/03/30 - first public release

  2007 Otto Donder. General Public License

--------------------------------------------------------------------------

http://www.chairod.de
http://http://www.gnome-look.org/usermanager/search.php?username=ottlux

e-mail : o.donder@chairod.de

--------------------------------------------------------------------------

Hope You like it.


			===============
			 Green edition By Bodom

			   Hope You like it too :)
			===============
