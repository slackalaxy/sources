// $Id: codonJC.cpp 962 2006-11-07 15:13:34Z privmane $

#include "codonJC.h"



