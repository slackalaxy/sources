// $Id: searchStatus.cpp 962 2006-11-07 15:13:34Z privmane $

#include "searchStatus.h"

searchStatus::searchStatus(const MDOUBLE startingTmp,const MDOUBLE factor ):
  _currentTmp(startingTmp),
  _factor(factor) {}


