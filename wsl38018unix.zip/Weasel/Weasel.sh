#!/bin/bash
java -Xmx768m -jar Weasel.jar Weasel
