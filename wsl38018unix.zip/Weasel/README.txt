Weasel is a Java program and should function on any system with Java v1.7 or later installed, including versions of unix. However, it is recommended that the most recent Java version compatible with your system be used.  

If you have a previous version of Weasel installed, rename its folder to, for example, "WeaselOld" and drag this new Weasel folder to the same location.  Your existing license code will still apply.  

The Weasel folder should be kept intact, enclosing the Weasel.jar file and accessories.  It may be stored anywhere on your system.  

Double-clicking the file Weasel.jar will launch the program, however Weasel can also be launched from a command window by moving to the Weasel folder and using a command like: 

"java -Xmx768m -jar Weasel.jar Weasel" where "768m" indicates the allocation of 768MB memory to the program heap.

 More memory can be allocated if you have it available.  Note that, if Weasel is launched by double-clicking the file Weasel.jar, the program may be allocated only 64 MB or less which will limit the size and number of data files handled in a Weasel session. It is therefore preferable to use a launch command as described or a shell script similar to the Weasel.sh enclosed.  To make the script executable, use the command: chmod +x Weasel.sh.  The procedure to make the script double-clickable will depend on your system (e.g. see http://askubuntu.com/questions/465531/how-to-make-a-shell-file-execute-by-double-click). 

If you are a new user, you may test Weasel over a 30 day trial period.  If you decide to keep it, apply for a license on line at http://www.frankbattye.com.au/Weasel/WeaselLicence.html or, if that is not possible, use the enclosed application form.  

Good luck with your Weasel trial. 
