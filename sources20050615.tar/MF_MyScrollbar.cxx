/* MF_MyScrollbar.cxx */


#include "MF_MyScrollbar.H"

MF_MyScrollbar::MF_MyScrollbar(int x, int y, int w, int h)
  : Fl_Scrollbar(x, y, w, h)
{
  ;
}

void MF_MyScrollbar::dessine(void)
{
  draw();
}

void MF_MyScrollbar::pos(int val)
{
  //  value((double)val);
  ;
}
