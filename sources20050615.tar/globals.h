#ifndef _GLOBALS_H_
#define _GLOBALS_H_

#include "lalnview.h"

extern int _MENU_OPENFEAT_;

extern int NBSEQ;
extern int LGSEQMAX;
extern int NBBLOC;
extern int NBSEG;
extern int NEWSEQ;
extern int COMPLEMENT;

extern int GET_SEQ_FROM_SIM;
extern int GET_FEAT_FROM_SIM;

extern struct COLOR color_lg[NBCOL];
extern double y_color;
extern char cur_color[30];
extern struct FEATURE *tab_feat;

extern int has_features; /* = TRUE or FALSE */
extern int NBFEAT; /* = nombre de features a decrire */
extern double yfeat[2];	/* position du milieu des features sur axe y */

extern double dist12; 	/* distance between the 2 seq. on the screen */

extern struct SEG *segm;
extern struct SEQ seq[2];
extern int cur_seq_view;  /* Nb of residues visible on the screen */


extern double left_margin, right_margin;
extern double feat_decal;	/* decalage des features par rapport au sequences */

extern double lrg_box;	/* largeur des boites representant les blocs de similitude */
extern int scale_pas; /* graduation pour representation de l'echelle */

extern char aln_fic_name[300];
extern char aln_fic_name_short[300];
extern double scale_factor;
extern double char_width, char_height;
extern char error_mess[500];

extern float seuil_score_sim; /* score mini de similitude pour reporter les blocs */

extern char **seq_alignee;	/* vecteur de sequences alignees lg = LINAL */
extern int nb_ligne_aln;	/* nb de ligne dans alignement */
extern char **empty_aln;
extern int cur_num_line;	/* numero de la ligne selectionnee */

/* scroller des sequences */
extern double maxscroll;

extern char lis_error_mess[20][80];
extern char sim_parameter[500];


#endif
