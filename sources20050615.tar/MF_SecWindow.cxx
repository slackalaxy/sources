/* MF_SecWindow.cxx */

#include "MF_SecWindow.H"
#include "MenuCb.H"
#include "globals.h"



FL_EXPORT MF_SecWindow::MF_SecWindow(int x, int y, int w, int h, char * lbl) :
  Fl_Window(x,y,w,h,lbl)
{
  t_ = new MF_Text(0,0,w,h);
  this->add(t_);
  this->resizable(this);
}

void MF_SecWindow::raz(void)
{
  if(t_)
    t_->raz();
}

void MF_SecWindow::afficheBloc(int numbloc, int numSeq){ t_->afficheBloc(numbloc, numSeq); }

void MF_SecWindow::update(void){ this->draw(); }
