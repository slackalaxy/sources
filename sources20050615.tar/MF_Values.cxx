/* MF_Values.cxx */

#include "MF_Values.H"



float MF_Values::scoMin(void){ return scoMin_; }
float MF_Values::identityMin(void){ return identityMin_; }
int MF_Values::lenghtMin(void){ return lenghtMin_; }
int MF_Values::SEQSPACE(void){ return SEQSPACE_; }
double MF_Values::rapport(void){ return rapport_; }
char *MF_Values::srcFile(void){ return srcFile_; }



void MF_Values::scoMin(float scoMin){ scoMin_ = scoMin; }
void MF_Values::identityMin(float identityMin){ identityMin_ = identityMin; }
void MF_Values::lenghtMin(int lenghtMin){ lenghtMin_ = lenghtMin; }
void MF_Values::SEQSPACE(int SEQSPACE){ SEQSPACE_ = SEQSPACE; }
void MF_Values::rapport(double rapport){ rapport_ = rapport; }
void MF_Values::srcFile(char *srcFile){ srcFile_ = strdup(srcFile); }
