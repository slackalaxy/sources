#ifndef _GLOBALS_H_
#define _GLOBALS_H_

#include "lalnview.h"

int  _MENU_OPENFEAT_;
int NBSEQ;
int LGSEQMAX;
int NBBLOC;
int NBSEG;
int NEWSEQ;
int COMPLEMENT;
int GET_SEQ_FROM_SIM;
int GET_FEAT_FROM_SIM;

struct COLOR color_lg[NBCOL];
double y_color;
char cur_color[30];
struct FEATURE *tab_feat;

int has_features; /* = TRUE or FALSE */
int NBFEAT; /* = nombre de features a decrire */
double yfeat[2];	/* position du milieu des features sur axe y */

double dist12; 	/* distance between the 2 seq. on the screen */

struct SEG *segm;
struct SEQ seq[2];
int cur_seq_view;  /* Nb of residues visible on the screen */



double left_margin, right_margin;
double feat_decal;	/* decalage des features par rapport au sequences */

double lrg_box;	/* largeur des boites representant les blocs de similitude */
int scale_pas; /* graduation pour representation de l'echelle */


char aln_fic_name[300];
char aln_fic_name_short[300];
double scale_factor;
double char_width, char_height;
char error_mess[500];

float seuil_score_sim; /* score mini de similitude pour reporter les blocs */

char **seq_alignee;	/* vecteur de sequences alignees lg = LINAL */
int nb_ligne_aln;	/* nb de ligne dans alignement */
char **empty_aln;
int cur_num_line;	/* numero de la ligne selectionnee */

/* scroller des sequences */
double maxscroll;

char lis_error_mess[20][80];

char sim_parameter[500];


#endif
