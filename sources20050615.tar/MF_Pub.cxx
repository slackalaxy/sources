/* MF_Pub.cxx */

#include <stdlib.h>
#include <string.h>
#include "MF_Pub.H"


MF_Pub::MF_Pub(int x, int y, int w, int h)
  : Fl_Widget(x, y, w, h)
{
  ;
}


void MF_Pub::draw(void)
{
  char * txt;

  txt = strdup("LALNVIEW");
  
  fl_font(FL_HELVETICA, 18);

  fl_rectf(x(), y(), w(), h(), FL_WHITE);
  fl_color(FL_BLACK);
  fl_draw(txt, x(), y(), w(), h(), FL_ALIGN_CENTER);
}
