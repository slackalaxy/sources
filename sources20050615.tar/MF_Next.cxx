/* MF_NextBloc.cxx */


#include "MF_Next.H"


MF_Next::MF_Next(int sens, int x, int y, int w, int h, char *lbl)
  : Fl_Button(x, y, w, h, lbl)
{
  sens_ = sens;
}


int MF_Next::sens()
{
  return sens_;
}
