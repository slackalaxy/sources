# gperfection2
Update gperfection2 icons to gtk3 naming spec

GTK2 inconset by Lokheed
https://lokheed.deviantart.com/art/gperfection2-Icon-Set-18530981
